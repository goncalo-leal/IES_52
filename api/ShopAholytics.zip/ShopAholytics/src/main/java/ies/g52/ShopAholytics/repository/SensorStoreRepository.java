package ies.g52.ShopAholytics.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import ies.g52.ShopAholytics.models.SensorStore;

public interface SensorStoreRepository extends JpaRepository<SensorStore,Integer> {
    
    //ver o que precisa depois;
    
}