package ies.g52.ShopAholytics.views;

public interface ShoppingIDMappingView {
    int getId();
    String getName();
}
