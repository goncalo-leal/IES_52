package ies.g52.ShopAholytics.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ies.g52.ShopAholytics.models.ShoppingManager;

public interface ShoppingManagerRepository  extends JpaRepository<ShoppingManager,Integer> {
    //ver o que precisa depois;
}
