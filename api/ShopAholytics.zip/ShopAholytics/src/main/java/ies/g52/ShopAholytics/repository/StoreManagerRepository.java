package ies.g52.ShopAholytics.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ies.g52.ShopAholytics.models.StoreManager;

public interface StoreManagerRepository  extends JpaRepository<StoreManager,Integer> {
    
    //ver o que precisa depois;
    
}
