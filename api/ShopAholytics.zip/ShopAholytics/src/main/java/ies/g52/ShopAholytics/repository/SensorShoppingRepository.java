package ies.g52.ShopAholytics.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import ies.g52.ShopAholytics.models.SensorShopping;

public interface SensorShoppingRepository extends JpaRepository<SensorShopping,Integer> {
    
    //ver o que precisa depois;
    
}