package ies.g52.ShopAholytics.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import ies.g52.ShopAholytics.models.SensorPark;

public interface SensorParkRepository  extends JpaRepository<SensorPark,Integer> {
    
 
    
}
