package ies.g52.ShopAholytics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopAholyticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
